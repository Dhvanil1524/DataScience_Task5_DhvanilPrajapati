#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Lasso
from sklearn.metrics import mean_squared_error, mean_absolute_error
import numpy as np


file_path = "C:\\Users\\dhvan\\OneDrive\\Desktop\\100_Sales.csv"  
data = pd.read_csv(file_path)

data_cleaned = data.drop(columns=["Unnamed: 9", "Unnamed: 10"], errors='ignore')

numerical_data = data_cleaned.select_dtypes(include=["float64", "int64"])

numerical_data = numerical_data.dropna()

X = numerical_data.drop(columns=["Total_Profit"])
y = numerical_data["Total_Profit"]


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

alphas = np.linspace(0.111, 12, 100)
best_alpha = None
min_mse = float("inf")

for alpha in alphas:
    lasso = Lasso(alpha=alpha, random_state=42)
    lasso.fit(X_train, y_train)
    y_pred = lasso.predict(X_test)
    mse = mean_squared_error(y_test, y_pred)
    if mse < min_mse:
        min_mse = mse
        best_alpha = alpha

# Calculate MSE, MAE, and RMSE for the best alpha
lasso_best = Lasso(alpha=best_alpha, random_state=42)
lasso_best.fit(X_train, y_train)
y_pred_best = lasso_best.predict(X_test)

mse_best = mean_squared_error(y_test, y_pred_best)
mae_best = mean_absolute_error(y_test, y_pred_best)
rmse_best = np.sqrt(mse_best)

print("Best Alpha:", best_alpha)
print("Mean Squared Error (MSE):", mse_best)
print("Mean Absolute Error (MAE):", mae_best)
print("Root Mean Squared Error (RMSE):", rmse_best)

